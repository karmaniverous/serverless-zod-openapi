import type { StageParams } from './stageSchema';

export const devStageParams: StageParams = {
  STAGE: 'dev',
  DOMAIN_NAME: 'api.dev.example.test',
};
